import java.util.Scanner;
import static java.lang.System.*;


public class Main {
    public static Scanner scan = new Scanner(in);
    public static void main(String[] args) {
        int start = scan.nextInt();
        int end = scan.nextInt();
        int cools = 0;
        for(int i = start; i <= end; i++){
            if(cool(i)) {
                cools++;
            }
        }
        out.println(cools);
    }
    public static boolean cool(int target){
        boolean square = false;
        boolean cube = false;
        for(int i = 0; i <= target; i++){
            if(i*i*i == target){
                cube = true;
            }
            if(i*i == target){
                square = true;
            }
        }
        return cube & square;
    }
}