import java.util.Scanner;
import static java.lang.System.*;
import java.util.ArrayList;


public class Main {
    public static Scanner scan = new Scanner(in);
    public static void main(String[] args) {
        ArrayList<String> turn = new ArrayList<String>();
        ArrayList<String> place = new ArrayList<String>();
        turn.add("");
        place.add("HOME");
        do {
            turn.add(scan.nextLine());
            place.add(scan.nextLine());
        } while (!place.get(place.size() - 1).equals("SCHOOL"));
        for(int i = 1; i < place.size()-1; i++){
            if(turn.get(turn.size() - i).equals("R")){
                out.println("Turn LEFT onto "+place.get(place.size()-i-1)+" street.");
            }
            else if(turn.get(turn.size() - i).equals("L")){
                out.println("Turn RIGHT onto "+place.get(place.size()-i-1)+" street.");
            }
        }
        if(turn.get(1).equals("R")){
            out.println("Turn LEFT into your HOME.");
        }
        else if(turn.get(1).equals("L")){
            out.println("Turn RIGHT into your HOME.");
        }
    }
}